package com.zellow777.beadando.enums;

public enum ActivityTypeEnum {
    LECTURE, LABORATORY, SPORTS, ARTS, MEETING
}
