package com.zellow777.beadando.repository;

import com.zellow777.beadando.model.Activity;
import org.springframework.data.repository.CrudRepository;

public interface ActivityRepository extends CrudRepository<Activity, Integer>{
}
